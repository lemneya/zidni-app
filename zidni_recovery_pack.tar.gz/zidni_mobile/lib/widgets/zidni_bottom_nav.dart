import 'package:flutter/material.dart';

class ZidniBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const ZidniBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      shape: const CircularNotchedRectangle(),
      notchMargin: 8.0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          _buildNavItem(context, icon: Icons.home_outlined, label: 'Home', index: 0),
          _buildNavItem(context, icon: Icons.support_agent_outlined, label: 'Alwakeel', index: 1),
          const SizedBox(width: 48), // placeholder for the FAB notch
          _buildNavItem(context, icon: Icons.payment_outlined, label: 'Pay', index: 3),
          _buildNavItem(context, icon: Icons.person_outline, label: 'Me', index: 4),
        ],
      ),
    );
  }

  Widget _buildNavItem(
    BuildContext context, {
    required IconData icon,
    required String label,
    required int index,
  }) {
    final bool isSelected = currentIndex == index;
    final Color color = isSelected ? Theme.of(context).primaryColor : Colors.grey;

    return IconButton(
      icon: Icon(icon, color: color),
      onPressed: () => onTap(index),
      tooltip: label,
    );
  }
}