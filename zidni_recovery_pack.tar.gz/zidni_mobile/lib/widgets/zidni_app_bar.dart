import 'package:flutter/material.dart';

class ZidniAppBar extends StatelessWidget implements PreferredSizeWidget {
  const ZidniAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white,
      foregroundColor: Colors.black,
      elevation: 1,

      // START (right in RTL): Search, Map
      leading: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(icon: const Icon(Icons.search), onPressed: () {}),
          IconButton(icon: const Icon(Icons.map_outlined), onPressed: () {}),
        ],
      ),
      leadingWidth: 120,

      // END (left in RTL): Ravigh, Apps  ✅ (fixed order)
      actions: [
        IconButton(
          icon: const Icon(Icons.lightbulb_outline), // Ravigh
          onPressed: () {},
        ),
        IconButton(
          icon: const Icon(Icons.apps),
          onPressed: () {},
        ),
      ],

      // CENTER: Eyes
      title: IconButton(
        icon: const Icon(Icons.visibility_outlined),
        onPressed: () {},
      ),
      centerTitle: true,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
