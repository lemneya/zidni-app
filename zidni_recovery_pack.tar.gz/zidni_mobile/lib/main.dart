import 'package:flutter/material.dart';
import 'services/stt_engine_speech_to_text.dart';
import 'shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ZidniApp());
}

class ZidniApp extends StatefulWidget {
  const ZidniApp({super.key});
  @override
  State<ZidniApp> createState() => _ZidniAppState();
}

class _ZidniAppState extends State<ZidniApp> {
  late final SttEngineSpeechToText _sttEngine;

  @override
  void initState() {
    super.initState();
    _sttEngine = SttEngineSpeechToText();
    // NO initialize() here
  }

  @override
  void dispose() {
    _sttEngine.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Zidni',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: ZidniShell(sttEngine: _sttEngine),
    );
  }
}
