import 'package:flutter/material.dart';
import 'services/stt_engine.dart';
import 'widgets/gul_control.dart';
import 'widgets/zidni_app_bar.dart';
import 'widgets/zidni_bottom_nav.dart';

// Placeholder screens for the bottom navigation
class PlaceholderScreen extends StatelessWidget {
  final String title;
  const PlaceholderScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(title, style: Theme.of(context).textTheme.headlineMedium),
    );
  }
}

class ZidniShell extends StatefulWidget {
  final SttEngine sttEngine;

  const ZidniShell({
    super.key,
    required this.sttEngine,
  });

  @override
  State<ZidniShell> createState() => _ZidniShellState();
}

class _ZidniShellState extends State<ZidniShell> {
  int _selectedIndex = 0;

  // GUL has no screen, so we map indices to screen widgets
  final List<Widget> _screens = const [
    PlaceholderScreen(title: 'Home'),
    PlaceholderScreen(title: 'Alwakeel'),
    SizedBox.shrink(), // Placeholder for GUL index
    PlaceholderScreen(title: 'Pay'),
    PlaceholderScreen(title: 'Me'),
  ];

  void _onItemTapped(int index) {
    // GUL is at index 2 and has no screen.
    if (index == 2) return;
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Per instructions, force RTL for the shell
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: const ZidniAppBar(),
        body: _screens[_selectedIndex],
        floatingActionButton: GulControl(
          sttEngine: widget.sttEngine,
          onSttResult: (_) {
            // No actions for now
          },
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        bottomNavigationBar: ZidniBottomNav(
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        ),
      ),
    );
  }
}
